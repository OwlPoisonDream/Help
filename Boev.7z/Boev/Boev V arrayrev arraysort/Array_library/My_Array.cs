﻿using System;

namespace Array_library
{
    public class My_Array
    {
        int[] int_arr;
        int x;
        int z;
        public My_Array(int n)
        {
            int_arr = new int[n];
        }

        public override string ToString()
        {
            string s = "";
            for (int i = 0; i < int_arr.Length; i++)
            {
                s += int_arr[i] + " ";
            }
            return s;
        }
        public void arr_fill(int n) 
        {
            Random value = new Random();
            for (int i = 0; i < n; i++)
            {
                int_arr[i] = value.Next(-1000, 1001);
            }
        }
        public void arr_fill(int i, int a)
        {
            int_arr[i] = a;
        }
        public int IndexOf(int el)
        {
            
            for (int i=0; i<int_arr.Length; i++)
            {
                if (int_arr[i] == el)
                {
                    return i;                    
                }
            }
            return -1;
        }
        public void Sort(int s)
        {
            if (s == 0) //Сортировка по возрастанию
            {
                for (int i=0; i < int_arr.Length; i++)
                {
                    for (int j = 0; j < int_arr.Length - 1; j++)
                    {
                        if (int_arr[j] > int_arr[j + 1])
                        {
                            int z = int_arr[j];
                            int_arr[j] = int_arr[j + 1];
                            int_arr[j + 1] = z;
                        }
                    }
                }
            }
            else if(s==1) //Сортировка по убыванию
            {
                for (int i = 0; i < int_arr.Length; i++)
                {
                    for (int j = 0; j < int_arr.Length - 1; j++)
                    {
                        if (int_arr[j] < int_arr[j + 1])
                        {
                            int z = int_arr[j];
                            int_arr[j] = int_arr[j + 1];
                            int_arr[j + 1] = z;
                        }
                    }
                }
            }
        }
        public void Reverse(int s)
        {
            for (int i = 0; i < int_arr.Length; i++)
            {
                for (int j = int_arr.Length-1; j > 0; j--)
                {
                    z = int_arr[j];
                    x = int_arr[i];
                    int_arr[i] = z;
                    int_arr[j] = x;
                    if (i == j || i > j) break;
                }
            }
        }
    }
}
