﻿using System;
using Array_library;

namespace Boev_V_arrayrev_arraysort
{
    class Program
    {
        static void Main(string[] args)
        {
            bool flag = true;
            int n = 0;
            int a;
            int el;
            int s;
            while (flag)
            {
                Console.WriteLine("Введите размер массива (число > 0)");
                try
                {
                    n = Convert.ToInt32(Console.ReadLine());
                    if (n < 1) continue;
                    flag = false;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            My_Array int_arr = new My_Array(n);
            Console.WriteLine(int_arr);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Введите элемент массива");
                a = Convert.ToInt32(Console.ReadLine());
                int_arr.arr_fill(i, a);
            }
            Console.WriteLine(int_arr);
            //Console.WriteLine("Введите элемент, по которому проводится поиск");
            //el = Convert.ToInt32(Console.ReadLine());
            //int _index1 = int_arr.IndexOf(el);
            //Console.WriteLine(_index1);
            //Console.WriteLine("Введите индекс операции: 0 - для сортировки по возрастанию, 1 - для сортировки по убыванию");
            s = Convert.ToInt32(Console.ReadLine());
            //if (s == 0 || s == 1)
            //{
            //    int_arr.Sort(s);
            //    Console.WriteLine(int_arr);
            //}
            //else
            //{
            //    Console.WriteLine("Вы ввели не тот индекс операции");
            //}
            int_arr.Reverse(s);
            Console.WriteLine(int_arr);
        }
    }
}
