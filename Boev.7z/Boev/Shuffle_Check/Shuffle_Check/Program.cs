﻿using System;

namespace Shuffle_Check
{
    class Program
    {
        public static bool Shuffle_Check(string str1, string str2)
        {
            if (str1.Length == str2.Length)
            {
                int i = 0;
                int j = 0;
                char symb1;
                char symb2;
                int count = 0;
                while (i < str1.Length)
                {
                    while (j < str2.Length)
                    {
                        symb1 = str1[i];
                        symb2 = str2[j];
                        if (symb1 == symb2)
                        {
                            i++;
                            if (i >= str1.Length)
                            {
                                break;
                            }
                        }
                        j++;
                        if (symb1 != symb2 & i!=(j-1))
                        {
                            i++;
                            count++;
                        }
                    }
                    j = 0;
                }
                Console.WriteLine(count);
                if (count == 0)
                {

                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите первую строку");
            string str1 = Console.ReadLine();
            Console.WriteLine("Введите вторую строку");
            string str2 = Console.ReadLine();
            Console.WriteLine("Строка является перестановкой:" + Shuffle_Check(str1, str2));
        }
    }
}
