﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Guess_Number
{
    public partial class Form2 : Form
    {
        int comp_num;
        int count=0;
        public Form2()
        {
            InitializeComponent();
            Random rnd = new Random();
            comp_num = rnd.Next(1, 100);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.Parse(textBox1.Text) == comp_num)
            {
                MessageBox.Show("Вы угадали число, Вам потребовалось "+ count + " попыток");
            }
            else if (int.Parse(textBox1.Text) > comp_num)
            {
                MessageBox.Show("Ваше число больше числа, заданного компьютером");
                count ++;
            }
            else
            {
                MessageBox.Show("Ваше число меньше числа, заданного компьютером");
                count++;
            }
        }
    }
}
