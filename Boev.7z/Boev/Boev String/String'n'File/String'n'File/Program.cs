﻿using System;
using System.Text;
using System.IO;

namespace String_n_File
{
    //Задание:
    //Написать программу, которая получает с файла строки стихотворения
    //И записывает их в другой файл, переворачивая строку, с сохранением абзацев
    class Program
    {
        static void Main(string[] args)
        {
            char[] poemstr;
            string revstr = "";
            string b = "";
            StreamReader sr = new StreamReader("C:\\Users\\user\\Downloads\\Boev String\\poema1.txt");
            StreamWriter sw = new StreamWriter("C:\\Users\\user\\Downloads\\Boev String\\revpoem.txt");
            while (!sr.EndOfStream) 
            {
                poemstr = sr.ReadLine().ToCharArray();
                for (int i = 0; i < poemstr.Length; i++)
                {
                    
                    b = poemstr[poemstr.Length-i-1].ToString();
                    revstr += b;
                    Console.Write(b);
                    Console.WriteLine(revstr);
                    if (revstr.Length == poemstr.Length)
                    {
                        sw.WriteLine(revstr);

                        revstr = "";
                    }
                }
                Console.WriteLine(revstr);
                if (poemstr.Length == 0) sw.WriteLine("");
            }

            sr.Close();
            sw.Close();
        }
    }
}
