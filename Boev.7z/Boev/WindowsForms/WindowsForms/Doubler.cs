﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsForms;

namespace WindowsForms
{
    class Doubler
    {
        public static int Random_final()
        {
            int finalnum;
            Random finnum = new Random();
            finalnum = finnum.Next(100, 1000);
            return finalnum;
        }
        public static int Random_first()
        {
            int firstnum;
            Random firnum = new Random();
            firstnum = firnum.Next(0, 99);
            return firstnum;
        }
    }
}
