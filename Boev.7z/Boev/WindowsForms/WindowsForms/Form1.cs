﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Stack<string> numsave = new Stack<string>();
        public Form1()
        {
            InitializeComponent();
            label5.Text = WindowsForms.Doubler.Random_final().ToString();
            label4.Text = WindowsForms.Doubler.Random_first().ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (label6.Text == "0")
            {
                numsave.Push(label4.Text);
            }
            label4.Text = (int.Parse(label4.Text) + 1).ToString();
            label6.Text = (int.Parse(label6.Text) + 1).ToString();
            if (label4.Text == label5.Text)
            {
                MessageBox.Show("Вы победили. Вам понадобилось" + " " + label6.Text + " " + "шаг/-а/-ов");
            }
            if (int.Parse(label4.Text) > int.Parse(label5.Text))
            {
                MessageBox.Show("Вы проиграли. Нажмите Сбросить, чтобы попробовать снова");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (label6.Text == "0")
            {
                numsave.Push(label4.Text);
            }
            label4.Text = (int.Parse(label4.Text) * 2).ToString();
            label6.Text = (int.Parse(label6.Text) + 1).ToString();
            if (label4.Text == label5.Text)
            {
                MessageBox.Show("Вы победили. Вам понадобилось" + " " + label6.Text + " " + "шаг/-а/-ов");
            }
            if (int.Parse(label4.Text) > int.Parse(label5.Text))
            {
                MessageBox.Show("Вы проиграли. Нажмите Сбросить, чтобы попробовать снова");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label6.Text = 0.ToString();
            label4.Text = numsave.Pop();
        }
    }
}
